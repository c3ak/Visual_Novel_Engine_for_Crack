import {McpServer} from '@modelcontextprotocol/server';
import {serveStdio} from '@modelcontextprotocol/server/stdio';
import * as z from 'zod/v4';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {resolve} from 'node:path';
import {createBridge,attachBridge} from './bridge.mjs';

const entry=fileURLToPath(import.meta.url);
export function connectionConfig(){
    const port=process.argv.find(argument=>argument.startsWith('--port=')),args=port?[entry,port]:[entry];
    return {claude:{mcpServers:{'vn-studio':{command:process.execPath,args}}},
        codex:`[mcp_servers.vn-studio]\ncommand = ${JSON.stringify(process.execPath)}\nargs = ${JSON.stringify(args)}\n`};
}
export function createStudioServer(bridge){
    const server=new McpServer({name:'vn-cartridge-studio',version:'1.0.0'});
    const register=(name,description,schema,operation,readOnly=true)=>server.registerTool(name,{
        description,inputSchema:schema,annotations:{readOnlyHint:readOnly,destructiveHint:!readOnly,openWorldHint:false}
    },async args=>{
        try{const result=await bridge.call(operation,args);return {content:[{type:'text',text:JSON.stringify(result)}]};}
        catch(error){return {content:[{type:'text',text:error.message}],isError:true};}
    });
    server.registerTool('studio_connection',{description:'Get the local studio URL. Open it in a browser, open MCP 연결, and connect the intended cartridge.',inputSchema:z.object({})},async()=>({content:[{type:'text',text:JSON.stringify(await bridge.status())}]}));
    const revision=z.number().int().nonnegative().describe('Revision returned by the latest studio_status/read operation. Stale writes are rejected.');
    const path=z.string().min(1).max(500);
    register('studio_status','Read the connected cartridge summary, current revision and validation errors. Call before changing files.',z.object({}),'status');
    register('studio_list_files','List cartridge-relative paths, sizes and types. Never accesses files outside the open cartridge.',z.object({}),'list_files');
    register('studio_read_file','Read one file in the open cartridge. Text or base64; at most 2 MiB.',z.object({path,encoding:z.enum(['text','base64']).default('text')}),'read_file');
    const change=z.object({path,content:z.string().max(3*1024*1024).optional(),encoding:z.enum(['text','base64']).default('text'),remove:z.boolean().default(false)});
    register('studio_apply_changes','Atomically add, replace or remove cartridge files. Include manifest and module changes in one batch. Requires browser write permission and matching revision; validates before committing.',z.object({expectedRevision:revision,changes:z.array(change).min(1).max(40)}),'apply_changes',false);
    register('studio_set_openings','Replace the opening list while retaining other presentation settings. Content is VN script text.',z.object({expectedRevision:revision,openings:z.array(z.object({title:z.string().max(200),content:z.string().max(1024*1024)})).max(30)}),'set_openings',false);
    register('studio_set_module','Add or replace a complete module definition by id. Its referenced files must already exist; use apply_changes to add code and definition atomically.',z.object({expectedRevision:revision,module:z.record(z.string(),z.unknown())}),'set_module',false);
    register('studio_validate','Run the real engine package reader against the current cartridge without executing modules.',z.object({}),'validate');
    register('studio_get_manifest','Read the complete cartridge manifest with its current revision.',z.object({}),'manifest');
    return server;
}
export async function run(){
    if(process.argv.includes('--print-config')){process.stdout.write(JSON.stringify(connectionConfig(),null,2)+'\n');return;}
    const portArg=process.argv.find(argument=>argument.startsWith('--port='));
    const port=portArg?Number(portArg.slice(7)):19639;
    if(!Number.isInteger(port)||port<1024||port>65535)throw new Error('포트는 1024~65535 사이여야 합니다.');
    let bridge,owned=true;
    try{const html=await readFile(new URL('./studio.html',import.meta.url),'utf8');bridge=await createBridge({port,html,config:connectionConfig()});}
    catch(error){if(error.code!=='EADDRINUSE')throw error;owned=false;bridge=await attachBridge(`http://127.0.0.1:${port}`);}
    console.error(`VN Studio MCP ready: ${bridge.url}`);
    let closing=false;
    const close=async()=>{if(closing)return;closing=true;if(owned)await bridge.close();};
    process.on('SIGINT',()=>close().then(()=>process.exit(0)));process.on('SIGTERM',()=>close().then(()=>process.exit(0)));
    if(!process.argv.includes('--standalone')){
        const handle=serveStdio(()=>createStudioServer(bridge),{onerror:error=>console.error(error.message)});
        process.stdin.once('end',()=>{void handle.close().finally(close);});
    }
}
if(process.argv[1]&&entry===resolve(process.argv[1])){
    await run().catch(error=>{console.error(error.message);process.exitCode=1;});
}
