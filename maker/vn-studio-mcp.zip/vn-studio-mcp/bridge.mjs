import {createServer} from 'node:http';
import {randomBytes,randomUUID,timingSafeEqual} from 'node:crypto';

const LIMIT=8*1024*1024;
const json=(response,status,value)=>{response.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});response.end(JSON.stringify(value));};
async function body(request){
    let size=0;const chunks=[];
    for await(const chunk of request){size+=chunk.length;if(size>LIMIT)throw Object.assign(new Error('요청이 너무 큽니다.'),{status:413});chunks.push(chunk);}
    return JSON.parse(Buffer.concat(chunks).toString('utf8')||'{}');
}

export async function createBridge({port=19639,html,config}){
    const token=randomBytes(32).toString('hex');
    const queue=[],pending=new Map();let browser=null,base;
    function disconnect(reason='스튜디오 연결이 종료됐습니다.'){
        browser=null;queue.length=0;
        for(const request of pending.values()){clearTimeout(request.timer);request.reject(new Error(reason));}pending.clear();
    }
    const status=()=>({application:'vn-studio-mcp',version:'1.0.0',url:base,connected:Boolean(browser&&Date.now()-browser.seen<30000)});
    function call(operation,args={}){
        if(!status().connected)return Promise.reject(new Error('로컬 스튜디오의 MCP 연결 탭에서 연결을 눌러 주세요.'));
        if(pending.size>=16)return Promise.reject(new Error('대기 중인 요청이 많습니다. 잠시 후 다시 시도해 주세요.'));
        const id=randomUUID();
        return new Promise((resolve,reject)=>{
            const timer=setTimeout(()=>{pending.delete(id);const index=queue.findIndex(item=>item.id===id);if(index>=0)queue.splice(index,1);reject(new Error('스튜디오 응답 시간이 지났습니다. 브라우저 연결을 확인해 주세요.'));},60000);
            pending.set(id,{resolve,reject,timer});queue.push({id,operation,args});
        });
    }
    const server=createServer(async(request,response)=>{
        try{
            const host=`127.0.0.1:${server.address().port}`;
            if(request.headers.host!==host)return json(response,403,{error:'허용되지 않은 호스트입니다.'});
            const url=new URL(request.url,`http://${host}`);
            if(request.method==='GET'&&url.pathname==='/'){
                response.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','X-Frame-Options':'DENY','X-Content-Type-Options':'nosniff'});return response.end(html);
            }
            const origin=request.headers.origin;
            if((origin&&origin!==base)||request.headers['sec-fetch-site']==='cross-site')return json(response,403,{error:'다른 웹사이트의 연결은 허용하지 않습니다.'});
            if(request.method==='GET'&&url.pathname==='/api/health')return json(response,200,status());
            if(request.method==='GET'&&url.pathname==='/api/bootstrap')return json(response,200,{...status(),token,config});
            const header=String(request.headers.authorization||'');
            const expected=Buffer.from(`Bearer ${token}`),supplied=Buffer.from(header);
            if(supplied.length!==expected.length||!timingSafeEqual(supplied,expected))return json(response,401,{error:'연결 인증이 필요합니다.'});
            if(request.method!=='POST')return json(response,405,{error:'POST 요청만 지원합니다.'});
            if(!String(request.headers['content-type']||'').startsWith('application/json'))return json(response,415,{error:'JSON 요청이어야 합니다.'});
            const data=await body(request);
            if(url.pathname==='/api/connect'){
                if(browser&&Date.now()-browser.seen<30000&&browser.id!==data.clientId)return json(response,409,{error:'다른 스튜디오 창이 연결돼 있습니다. 기존 창에서 연결을 끊어 주세요.'});
                if(typeof data.clientId!=='string'||data.clientId.length>100)return json(response,400,{error:'잘못된 연결 ID입니다.'});
                browser={id:data.clientId,seen:Date.now()};return json(response,200,{ok:true});
            }
            if(url.pathname==='/api/tool'){
                if(typeof data.operation!=='string')return json(response,400,{error:'잘못된 도구 요청입니다.'});
                try{return json(response,200,{ok:true,result:await call(data.operation,data.args||{})});}
                catch(error){return json(response,409,{error:error.message});}
            }
            if(!browser||data.clientId!==browser.id)return json(response,409,{error:'스튜디오 연결이 만료됐습니다.'});
            browser.seen=Date.now();
            if(url.pathname==='/api/poll')return json(response,200,{requests:queue.splice(0)});
            if(url.pathname==='/api/respond'){
                const item=pending.get(data.id);
                if(item){pending.delete(data.id);clearTimeout(item.timer);if(data.error)item.reject(new Error(String(data.error)));else item.resolve(data.result);}
                return json(response,200,{ok:true});
            }
            if(url.pathname==='/api/disconnect'){disconnect();return json(response,200,{ok:true});}
            return json(response,404,{error:'알 수 없는 요청입니다.'});
        }catch(error){if(!response.headersSent)json(response,error.status||400,{error:error.message});else response.end();}
    });
    await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});
    base=`http://127.0.0.1:${server.address().port}`;
    return {url:base,token,status,call,async close(){disconnect();server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}};
}

export async function attachBridge(url){
    const response=await fetch(`${url}/api/bootstrap`,{signal:AbortSignal.timeout(3000)});
    if(!response.ok)throw new Error('이 포트의 MCP 연결 프로그램을 확인해 주세요.');
    const info=await response.json();
    if(info.application!=='vn-studio-mcp'||info.version!=='1.0.0')throw new Error('호환되는 스튜디오 MCP 연결 프로그램이 아닙니다.');
    return {url,async status(){const response=await fetch(`${url}/api/health`,{signal:AbortSignal.timeout(3000)});return response.json();},async call(operation,args){
        const result=await fetch(`${url}/api/tool`,{method:'POST',headers:{Authorization:`Bearer ${info.token}`,'Content-Type':'application/json'},body:JSON.stringify({operation,args}),signal:AbortSignal.timeout(65000)});
        const data=await result.json();if(!result.ok)throw new Error(data.error||'스튜디오 요청에 실패했습니다.');return data.result;
    },async close(){}};
}
