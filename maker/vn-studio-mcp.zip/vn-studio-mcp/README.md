# VN 카트리지 스튜디오 MCP 연결

Codex·Claude 등 로컬 MCP 클라이언트가 브라우저에 열어 둔 카트리지를 읽고 수정합니다. AI의 API 키를 스튜디오에 넣을 필요는 없습니다. AI 모델은 연결한 앱이 제공합니다.

## 시작

1. Node.js 20 이상을 준비합니다: https://nodejs.org/
2. 이 폴더의 `start-studio.cmd`를 실행합니다. macOS/Linux에서는 `node server.mjs --standalone`을 실행합니다.
3. http://127.0.0.1:19639/ 를 엽니다. 실행 창은 계속 열어 둡니다.
4. 스튜디오에서 카트리지를 열거나 새로 만듭니다.
5. **MCP 연결** 탭에서 **MCP 연결**을 누릅니다. 수정을 맡길 때만 **AI가 카트리지 파일을 수정하도록 허용**을 켭니다.
6. 같은 탭의 Claude JSON / Codex TOML 설정을 복사해 사용하는 AI 앱에 등록하고, 해당 MCP 서버를 다시 시작합니다.

현재 설치 경로를 반영한 설정이 생성되므로 이 폴더를 옮겼다면 설정도 다시 복사하세요. 기본 포트는 19639입니다. 여러 AI 앱은 먼저 실행한 연결 프로그램에 접속합니다.

Claude Desktop에서는 일반적인 `mcpServers` JSON 형식, Codex에서는 `[mcp_servers.vn-studio]` TOML 형식을 사용합니다. Codex 데스크톱의 MCP 서버 설정에서 명령과 인수를 직접 등록해도 됩니다. 연결 설정 파일을 자동으로 변경하거나 다른 서버 설정을 덮어쓰지는 않습니다.

AI 앱이 MCP 서버를 직접 시작하게 하려면 `command`를 Node 실행 파일, `args`를 이 폴더의 `server.mjs` 절대 경로로 설정하세요. 이 경우 별도의 `--standalone` 인수는 넣지 않습니다. `node server.mjs --print-config`로 예시를 출력할 수도 있습니다.

## AI에게 요청하는 예

> 스튜디오 연결 상태와 manifest를 읽어 줘. 현재 revision을 사용해서 오프닝을 두 개로 만들고, 변경 뒤 카트리지를 검증해 줘.

> 파일 목록과 장부 모듈의 HTML·JS·CSS를 읽고 표시를 수정해 줘. manifest와 코드 변경은 한 번에 적용하고 원래의 다른 설정은 유지해 줘.

## 제공 도구

- `studio_connection`: 로컬 스튜디오 주소와 연결 상태.
- `studio_status`, `studio_get_manifest`, `studio_list_files`, `studio_read_file`: 현재 카트리지 확인.
- `studio_apply_changes`: 파일 추가·교체·삭제를 묶어서 원자적으로 적용.
- `studio_set_openings`: 오프닝 목록 변경.
- `studio_set_module`: 모듈 정의 추가·교체. 새 코드 파일도 필요하면 apply_changes로 묶어 변경.
- `studio_validate`: 실제 엔진 판독기로 검증. 모듈 코드는 실행하지 않음.

수정 도구에는 직전 읽기에서 받은 `expectedRevision`이 필요합니다. 사용자가 그 사이 편집하면 다시 읽어야 합니다. 잘못된 패키지는 반영하지 않습니다. 브라우저에서 입력 중인 오류가 있으면 먼저 해결해 주세요.

읽기는 파일당 2 MiB까지, 수정은 파일당 2 MiB·한 번에 합계 4 MiB까지입니다. 기존 큰 미디어는 다시 전송하지 않고 카트리지 안에 유지합니다. 큰 그림이나 음악은 기존 스튜디오의 파일·미디어 추가로 넣습니다.

## 연결 범위

연결한 창의 카트리지 파일 맵만 제공합니다. 서버에 컴퓨터 파일 탐색, 임의 경로 읽기·쓰기, 셸 실행, 자바스크립트 실행 도구는 없습니다. 카트리지를 새로 열면 연결을 해제합니다. AI 변경은 브라우저 작업에 반영되며, 최종 배포 파일은 사용자가 **내보내기**로 저장합니다.

통신은 127.0.0.1에 한정하고 Host·Origin·일시적 연결 인증을 확인합니다. 공개 GitHub Pages 페이지에 직접 연결하는 방식이 아니라, 위 로컬 스튜디오에서 연결합니다. 클라우드 전용 AI 앱에서 이 로컬 주소에 직접 접속할 수 있다고 가정하지 마세요.

프로그램을 종료하려면 실행 창에서 Ctrl+C를 누릅니다. AI 앱이 실행한 서버는 앱에서 서버를 중지하면 종료됩니다. Node.js를 포함한 실행 환경은 이 ZIP에 포함하지 않습니다. 공식 MCP SDK와 필요한 실행 의존성은 ZIP에 포함합니다.

## 개발 및 검사

제작 원본 작업 폴더에서는 의존성 설치 후 `node --test test/bridge.test.mjs`를 실행합니다. `test/manual-probe.mjs`는 이미 연결한 시험용 브라우저를 대상으로 하는 개발자 점검 도구입니다.

출처: [공식 MCP SDK](https://ts.sdk.modelcontextprotocol.io/v2/), [MCP stdio 전송](https://modelcontextprotocol.io/specification/2025-11-25/basic/transports), [OpenAI 공식 MCP 설정 문서](https://learn.chatgpt.com/docs/extend/mcp?surface=cli). 배포본의 node_modules에 포함된 각 패키지의 라이선스와 NOTICE 파일을 유지합니다.
