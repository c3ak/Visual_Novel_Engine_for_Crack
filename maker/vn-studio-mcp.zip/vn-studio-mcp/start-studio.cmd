@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 20 or newer is required. Install it from https://nodejs.org/
  pause
  exit /b 1
)
echo Open http://127.0.0.1:19639/ in your browser.
echo Keep this window running while using the studio MCP connection.
node "%~dp0server.mjs" --standalone
pause
